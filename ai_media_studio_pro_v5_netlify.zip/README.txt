
AI Media Studio Pro v5 (30 Tools)

Upload the entire folder to Netlify.

Then go to:
Site settings → Environment Variables

Add:

Key: GEMINI_API_KEY
Value: your Gemini API key

Deploy and open your site.
